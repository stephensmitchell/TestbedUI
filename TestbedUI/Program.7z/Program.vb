Imports System.Threading
Imports Syncfusion.SfSkinManager
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Media
Imports System.Windows.Media.Imaging
Imports devDept.Eyeshot
Imports devDept.Eyeshot.Entities
Imports devDept.Geometry
Imports devDept.Graphics
Module Program
    Dim app As Application
    Dim grid As System.Windows.Controls.Grid
    Dim window As Window
    <STAThread>
    Public Sub Main()

        'TODO: Add mini logger
        Dim keepRunning As Boolean = True
        Console.WriteLine("Enter command ('/h' for list of commands):")
        While keepRunning
            Dim command As String = Console.ReadLine().ToLower()
            Select Case command
                Case "/ui-1"
                    Dim WindowTitleDesignName As String = "TestbedUI Design 01 - DEV MODE"
                    Console.WriteLine(WindowTitleDesignName & " is ready...")
                    Console.WriteLine(WindowTitleDesignName & " WindowState = WindowState.Minimized")
                    Dim thread = New Thread(Sub()
                                                SfSkinManager.ApplyStylesOnApplication = True
                                                app = New Application()
                                                window = New Window With {
                                                    .Title = WindowTitleDesignName,
                                                    .Width = 1920,
                                                    .Height = 1080,
                                                    .WindowStartupLocation = WindowStartupLocation.CenterScreen,
                                                    .WindowState = WindowState.Minimized,
                                                    .WindowStyle = WindowStyle.SingleBorderWindow,
                                                    .Background = Brushes.Black
                                                }
                                                grid = New System.Windows.Controls.Grid()
                                                'BuildGrid(grid)
                                                WindowLayout1.BuildGrid2(grid)
                                                window.Content = grid
                                                app.Run(window)
                                            End Sub)
                    thread.SetApartmentState(ApartmentState.STA)
                    thread.Start()
                Case "/ui-2"
                    Dim WindowTitleDesignName As String = "TestbedUI Design 02 - DEV MODE"
                    Console.WriteLine(WindowTitleDesignName & " is ready...")
                    Console.WriteLine(WindowTitleDesignName & " WindowState = WindowState.Minimized")
                    Dim thread = New Thread(Sub()
                                                SfSkinManager.ApplyStylesOnApplication = True
                                                app = New Application()
                                                window = New Window With {
                                                    .Title = WindowTitleDesignName,
                                                    .Width = 1920,
                                                    .Height = 1080,
                                                    .WindowStartupLocation = WindowStartupLocation.CenterScreen,
                                                    .WindowState = WindowState.Minimized,
                                                    .WindowStyle = WindowStyle.SingleBorderWindow,
                                                    .Background = Brushes.Black
                                                }
                                                grid = New System.Windows.Controls.Grid()
                                                'BuildGrid2(grid)
                                                WindowLayout1.BuildGrid2(grid)
                                                window.Content = grid
                                                app.Run(window)
                                            End Sub)
                    thread.SetApartmentState(ApartmentState.STA)
                    thread.Start()
                Case "/ui-3"
                    Dim WindowTitleDesignName As String = "TestbedUI Design 03 - DEV MODE"
                    Console.WriteLine(WindowTitleDesignName & " is ready...")
                    Console.WriteLine(WindowTitleDesignName & " WindowState = WindowState.Minimized")
                    Dim thread = New Thread(Sub()
                                                SfSkinManager.ApplyStylesOnApplication = True

                                                window = New Window With {
                                                    .Title = WindowTitleDesignName,
                                                    .Width = 1920,
                                                    .Height = 1080,
                                                    .WindowStartupLocation = WindowStartupLocation.CenterScreen,
                                                    .WindowState = WindowState.Minimized,
                                                    .WindowStyle = WindowStyle.SingleBorderWindow,
                                                    .Background = Brushes.Black
                                                }
                                                grid = New System.Windows.Controls.Grid()
                                                'BuildGrid2(grid)
                                                WindowLayout1.BuildGrid2(grid)
                                                window.Content = grid
                                                window.Show()

                                                If app Is Nothing Then
                                                    app = New Application()
                                                    app.Run(window)
                                                End If

                                            End Sub)
                    thread.SetApartmentState(ApartmentState.STA)
                    thread.Start()
                Case "/ui-4"
                    Dim WindowTitleDesignName As String = "TestbedUI Design 04 - DEV MODE"
                    Console.WriteLine(WindowTitleDesignName & " is ready...")
                    Console.WriteLine(WindowTitleDesignName & " WindowState = WindowState.Minimized")
                    Dim thread = New Thread(Sub()
                                                SfSkinManager.ApplyStylesOnApplication = True
                                                app = New Application()
                                                window = New Window With {
                                                    .Title = WindowTitleDesignName,
                                                    .Width = 1920,
                                                    .Height = 1080,
                                                    .WindowStartupLocation = WindowStartupLocation.CenterScreen,
                                                    .WindowState = WindowState.Minimized,
                                                    .WindowStyle = WindowStyle.SingleBorderWindow,
                                                    .Background = Brushes.Black
                                                }
                                                grid = New System.Windows.Controls.Grid()
                                                WindowLayout1.BuildGrid2(grid)
                                                window.Content = grid
                                                app.Run(window)
                                            End Sub)
                    thread.SetApartmentState(ApartmentState.STA)
                    thread.Start()
                Case "/r" 'TODO: Add restart functionality
                    Console.WriteLine("Restarting the application...")
                Case "/c"
                    LoadCalca()
                    RunNotepadAndWaitAsync()
                    RunNotepadAndSendTextAsync()
                Case "/h"
                    ShowHelp()
                Case "/e"
                    Environment.Exit(0)
                Case Else
                    Console.WriteLine("Invalid command. Type 'help' to see the list of valid commands.")
            End Select
        End While
    End Sub
    Private Sub ShowHelp()
        ' This function shows the help instructions.
        Console.WriteLine("Available commands:")
        Console.WriteLine("  /ui-1 - UI")
        Console.WriteLine("  /ui-2 - UI")
        Console.WriteLine("  /ui-3 - UI")
        Console.WriteLine("  /ui-4 - UI")
        Console.WriteLine("  /r - Restarts the application (not implemented)")
        Console.WriteLine("  /c - Macros")
        Console.WriteLine("  /h    - Shows this help message")
        Console.WriteLine("  /e    - Kills the application")
    End Sub

End Module
